var mysql = require('mysql');

class EntryDatabase {

/*  The table...
MariaDB [interview10]> describe AuctionItems;
+--------------------+---------------------+------+-----+---------+----------------+
| Field              | Type                | Null | Key | Default | Extra          |
+--------------------+---------------------+------+-----+---------+----------------+
| Id                 | bigint(20) unsigned | NO   | PRI | NULL    | auto_increment |
| FieldAgent         | char(32)            | YES  |     | NULL    |                |
| ProductCategory    | smallint(6)         | YES  |     | NULL    |                |
| ProductMake        | char(32)            | YES  |     | NULL    |                |
| ProductModel       | char(16)            | YES  |     | NULL    |                |
| ProductYear        | smallint(6)         | YES  |     | NULL    |                |
| ProductDescription | varchar(255)        | YES  |     | NULL    |                |
| Status             | char(1)             | YES  |     | NULL    |                |
| FinalPrice         | decimal(5,2)        | YES  |     | NULL    |                |
| ImageFile          | char(128)           | YES  |     | NULL    |                |
+--------------------+---------------------+------+-----+---------+----------------+
 */
    constructor() {

        this.con = mysql.createConnection({
            // host: "34.204.52.29",
            // user:  "Colesb",
            // password : "dhgMxbBMHswDmnDQ",
            // database : "interview10",
            host: "bcpractice.ce6wunnrmla1.us-east-2.rds.amazonaws.com",
            user: "Brian",
            password: "7C5o5ChXpt",
            database: "Laravel",
            port: 3306
        })

        this.con.connect((err) => {
            if (err) throw err;
            console.log("Connected");
        });


    }

    InsertRecord(fieldValuesString, res){
        var fieldValues = JSON.parse(fieldValuesString);
        var assignmentList = this.prepareAssignmentList(fieldValues);


        console.log(fieldValues);

        var insertStmt = "Insert into AuctionItems set " + assignmentList;
        console.log("SQL=" + insertStmt);
        var insertedID;
        this.con.query(insertStmt, (err, results) => {
            if (err) throw err;
            console.log("results from query:  ")
            console.log(results);
            insertedID = results.insertId;
            res.end(insertedID.toString());
        });

    }

    UpdateEntry(fieldValuesString, res){
        var fieldValues = JSON.parse(fieldValuesString);
        var assignmentList = this.prepareAssignmentList(fieldValues);

        console.log(fieldValues);

        var insertStmt = "Update AuctionItems set " + assignmentList + " where Id=" + fieldValues['Id'];
        console.log("SQL=" + insertStmt);
        var insertedID;
        this.con.query(insertStmt, (err, results) => {
            if (err) throw err;
            console.log("results from query:  ")
            console.log(results);
            res.end("done");
        });

    }

    prepareAssignmentList(fieldValues)
    {
        var assignmentList = "";
        var separator = "";

        console.log(fieldValues);

        var StringList = ["FieldAgent", "ProductMake", "ProductModel", "ProductDescription", "Status", "ImageFile"];
        for (var i = 0; i < StringList.length; i++) {
            var oneField = StringList[i];
            assignmentList += separator + oneField + "='" +  fieldValues[oneField].replace("'", "\\'") + "'";
            separator = ",";
        }

        var NumberList = ["ProductCategory", "ProductYear"];
        for (var i = 0; i < NumberList.length; i++) {
            var oneField = NumberList[i];
            assignmentList += separator + oneField + "=" + fieldValues[oneField];
            separator = ",";

        }

        return assignmentList;

    }

    FetchExisting(res){
        this.con.query("select * from AuctionItems", (err, results) => {
            if (err) throw err;
            console.log(results);
            res.end(JSON.stringify(results));
        });



    }

    DeleteEntry(victimID, res) {
        var deleteStmt = "delete from AuctionItems where Id = " + victimID;
        this.con.query(deleteStmt, (err, results) => {
            if (err) throw err;
            res.end("gone");
        });

    }

}

module.exports = EntryDatabase;