var express = require('express');
const EntryDatabase = require("./EntryDatabase.js");


var app = express();
//  app.set('view engine', 'pug');


app.post('/create', function(req, res){
    //  do the insert for a new row and returning the ID.  Get the JSON for the row from the post parameter
    //  Add the current date and time.
    let inData = "";
    req.on('data', chunk => {
        console.log("chunk: " + chunk)
        inData += chunk.toString();
    });
    req.on('end', () => {
        console.log("Indata to server: >" + inData + "<");
        // var body = querystring.parse(inData);
        // console.log(body);
        var dbHelper = new EntryDatabase();
        dbHelper.InsertRecord(inData, res);

        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Access-Control-Allow-Origin', '*');

        // res.end("Puzzle inserted");
    });
});

app.get('/read', function(req, res){
    var dbHelper = new EntryDatabase();
    dbHelper.FetchExisting(res);


    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Access-Control-Allow-Origin', '*');


});

app.delete('/delete', function(req,res) {
    var victim = req.query.Id;
    var dbHelper = new EntryDatabase();
    dbHelper.DeleteEntry(victim, res);
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Access-Control-Allow-Origin', '*');
});

app.post('/update', function(req,res) {
    let inData = "";
    req.on('data', chunk => {
        console.log("chunk: " + chunk)
        inData += chunk.toString();
    });
    req.on('end', () => {
        console.log("Indata to server for update: >" + inData + "<");
        // var body = querystring.parse(inData);
        // console.log(body);
        var dbHelper = new EntryDatabase();
        dbHelper.UpdateEntry(inData, res);

        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Access-Control-Allow-Origin', '*');

        // res.end("Puzzle inserted");
    });

});

const http = require('http');

const hostname = '127.0.0.1';
const port = 8081;




//
//
// const server = http.createServer((req, res) => {
//     res.statusCode = 200;
//     res.setHeader('Content-Type', 'text/plain');
//     res.end('Hello World\n');
// });











app.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});

