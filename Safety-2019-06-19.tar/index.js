import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//  import App from './App';
import * as serviceWorker from './serviceWorker';
import axios from 'axios';

class  RowHolder {
    static serialNumber =0 ;

    constructor(whichParent)
    {
        this.Id = -1;
        this.Status = "N";  //  For a new entry

        this.FieldAgent = "";   // <<  in production, would initialize this to logged in user
        this.ProductCategory = 0;  //  Unknown category
        this.ProductMake = "";
        this.ProductModel= "";
        this.ProductYear = ""; //  Site truck 1967, #60,  Refer truck 1968
        this.ProductDescription = "";
        this.ImageFile = "NextProductPlaceHolder.jpg";

        // this.FieldAgent = "me";   // <<  in production, would initialize this to logged in user
        // this.ProductCategory = 0;  //  Unknown category
        // this.ProductMake = "Matchbox";
        // this.ProductModel= "Refrigeration truck #44";
        // this.ProductYear = "1964"; //  Site truck 1967, #60,  Refer truck 1968
        // this.ProductDescription = "Refrigeration truck with back door that really opens and closes!  (Refrigeration unit not included.)";
        // this.ImageFile = "IMG_1210.jpg";

        this.Parent = whichParent;

        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleEdit = this.handleEdit.bind(this);
        this.handleImageFile = this.handleImageFile.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.prepareNewStateRowList = this.prepareNewStateRowList.bind(this);
        this.handleEditChange = this.handleEditChange.bind(this);
        this.isEditMode = true;

    }

    setFromJSON(dataSource) {
        var fieldList = ["Id", "FieldAgent", "ProductMake", "ProductModel", "ProductDescription", "Status", "ImageFile", "ProductCategory", "ProductYear"];
        for (var i = 0; i < fieldList.length; i++)
        {
            this[fieldList[i]] = dataSource[fieldList[i]];
        }
        this.isEditMode = false;
    }

    renderEntry() {
        if (this.isEditMode)
            return this.renderEditEntry();
        else
            return this.renderReadOnlyEntry();
    }

    renderEditEntry(){
        // alert("Entry data = " + JSON.stringify(this));
        var imageFileName = "/images/" + this.ImageFile;
        var thisIndex = this.Parent.state.RowData.indexOf(this);
        console.log("this index = " + thisIndex);
        return (
            <div key={RowHolder.serialNumber++}>

                <table><tbody>
                    <tr>
                        <td rowSpan="7" valign="top"><img src={imageFileName} height="200"  alt="Product Goes Here." /></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Field Agent: </span></td><td><input type="text" name="FieldAgent" className="editCell"  size="32" defaultValue={this.FieldAgent} /></td>
                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Category: </span></td><td><select name="ProductCategory">
                        <option value="0">Unknown</option>
                        <option value="1">General Truck</option>
                        <option value="2">Crane</option>
                        <option value="3">Firetruck</option>
                        <option value="4">Ambulance</option>
                        <option value="9999">Other</option>
                    </select></td>

                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Make: </span></td><td><input type="text" name="ProductMake"  className="editCell"  size="32" defaultValue={this.ProductMake} /></td>

                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Model: </span></td><td><input type="text" name="ProductModel" className="editCell"   size="32" defaultValue={this.ProductModel}/></td>
                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Year: </span></td><td><input type="text" name="ProductYear"  className="editCell"  size="4" defaultValue={this.ProductYear} /></td>
                    </tr>
                    <tr>
                        <td align="right" valign="top"><span className="labelCell">Description: </span></td><td  width="300px">
                            <textarea name="ProductDescription" className="editCell"  rows="4" cols="64" value={this.Parent.state.RowData[thisIndex].ProductDescription} onChange={this.handleEditChange}></textarea>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <input type="file" onChange={this.handleImageFile}/>

                        </td>
                        <td></td>
                        <td>
                            {this.makeEditButtonRow()}
                        </td>
                    </tr>
                    <tr><td colSpan="3"><hr /></td></tr>
                </tbody></table>


            </div>

        );

    }

    makeEditButtonRow() {
        //  If the Id is -1, then we have a new entry, so the only button we need is a Save.  Otherwise we need
        //  an Update and a Cancel button for entries being editted or Edit and Delete buttons for read-only entries.
        if (this.Id === -1)
            return (<button className="button" onClick={this.handleSubmit}>Save</button>);
        else
        {
            if (this.isEditMode)
                return (<div><button className="button" onClick={this.handleUpdate}>Update</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button className="button" onClick={this.handleCancel}>Cancel</button></div>);
            else
                return (<div><button className="button" onClick={this.handleSubmit}>Edit</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button className="button" onClick={this.handleDelete}>Delete</button></div>);

        }
    }

    renderReadOnlyEntry(){
        var imageFileName = "/images/" + this.ImageFile;
        return (
            <div  key={RowHolder.serialNumber++}>

                <table><tbody>
                    <tr>
                        <td rowSpan="7" valign="top" ><img src={imageFileName} height="200"  alt="snowplow" /></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Field Agent: </span></td>
                        <td><span className="readOnlyCell">{this.FieldAgent}</span> </td>
                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Category: </span></td><td><select name="ProductCategory">
                        <option value="0">Unknown</option>
                        <option value="1">General Truck</option>
                        <option value="2">Crane</option>
                        <option value="3">Firetruck</option>
                        <option value="4">Ambulance</option>
                        <option value="9999">Other</option>
                    </select></td>

                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Make: </span></td><td><span className="readOnlyCell">{this.ProductMake}</span> </td>

                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Model: </span></td><td><span className="readOnlyCell">{this.ProductModel}</span></td>
                    </tr>
                    <tr>
                        <td align="right"><span className="labelCell">Year: </span></td><td><span className="readOnlyCell">{this.ProductYear}</span></td>
                    </tr>
                    <tr>
                        <td align="right" valign="top"><span className="labelCell">Description: </span></td><td  width="300px"><span className="readOnlyCell">{this.ProductDescription}</span></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td><button className="button" onClick={this.handleEdit}>Edit</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button className="button" onClick={this.handleDelete}>Delete</button></td>
                    </tr>

                     <tr><td colSpan="3"><hr /></td></tr>


                </tbody></table>


            </div>

        );

    }



    handleImageFile(event){
        //  User selected the uploaded file.  We need to preserve it in this object's holder.
        this.ImageFile = event.target.files[0].name;
        this.ImageData = btoa(event.target.file[0]);

    }

    handleEditChange(event) {
        
    }

    handleSubmit()
    {
        //  We get a circular reference when we try to stringify the object, so we temporarily whipe out
        //  the parent reference before the stringify and then restore it.
        var tempParent = this.Parent;
        this.Parent = null;
        var dataToServer = JSON.stringify(this);
        this.Parent = tempParent;

        //  Adjust the parameters for the axios call to reflect a create (for a new entry) or
        //  an update (for an existing entry)
        var axiosParms =
            {
                method : "POST",
                url : "http://localhost:8081/create",
                data : dataToServer

            } ;


        //  Send the data to the server as a POST action.
        axios(axiosParms).then(res=> {
            //  should be returning the unique id for this entry.
            this.Id = res['data']; // the id of the new entry.

            this.prepareNewStateRowList(function(whichRow) {
                if (whichRow.Id === -1)
                {
                    //  We may have to clone the object.  We'll see if this works first
                    whichRow.isEditMode = true;
                    return whichRow;
                }
                else {
                    whichRow.isEditMode = false;
                    return whichRow;
                }
            }, true /* add new at beginning */);

            // const  imageToSave = new FormData();
            // imageToSave.append(
            //     'myFile',
            //
            // )


        });


    }

    handleUpdate()
    {
        //  We get a circular reference when we try to stringify the object, so we temporarily whipe out
        //  the parent reference before the stringify and then restore it.
        var tempParent = this.Parent;
        this.Parent = null;
        var dataToServer = JSON.stringify(this);
        console.log("collected data for update:  " + dataToServer);
        this.Parent = tempParent;

        //  Adjust the parameters for the axios call to reflect a create (for a new entry) or
        //  an update (for an existing entry)
        var axiosParms =
            {
                method : "POST",
                url : "http://localhost:8081/update",
                data : dataToServer

            } ;


        //  Send the data to the server as a POST action.
        axios(axiosParms).then(res=> {
            //  should be returning the unique id for this entry.
            this.Id = res['data']; // the id of the new entry.

            this.prepareNewStateRowList(function(whichRow) {
                if (whichRow.Id === -1)
                {
                    //  We may have to clone the object.  We'll see if this works first
                    whichRow.isEditMode = true;
                    return whichRow;
                }
                else {
                    whichRow.isEditMode = false;
                    return whichRow;
                }
            });

        });


    }
    /**
     * Handle a cancel edit by turning off the edit mode for the selected row and turning on edit
     * mode for the new entry row.
     */
    handleCancel()
    {
        this.prepareNewStateRowList(function(whichRow) {
            if (whichRow.Id === -1)
            {
                //  We may have to clone the object.  We'll see if this works first
                whichRow.isEditMode = true;
                return whichRow;
            }
            else {
                whichRow.isEditMode = false;
                return whichRow;
            }
        });


    }

    /**
     * Turn on editting for  row by setting the edit mode for the selected row and turning off
     * edit mode for all others.
     */
    handleEdit()
    {
        var testId = this.Id;
        this.prepareNewStateRowList(function(whichRow) {
                if (whichRow.Id === testId)
                {
                    //  We may have to clone the object.  We'll see if this works first
                    whichRow.isEditMode = true;
                    return whichRow;
                }
                else {
                    whichRow.isEditMode = false;
                    return whichRow;
                }
            });



    }

    /**
     * Delete this row. We remove it from the database and from the list held by the parent's state.
     */
    handleDelete()
    {
        if (window.confirm("Are you sure you want to delete the " + this.ProductYear + " " + this.ProductMake + " " + this.ProductModel + "?")){
            console.log("would delete this one");
            axios({
                method : 'DELETE',
                url : "http://localhost:8081/delete?Id=" + this.Id,

            }).then(res=> {
                //  Copy the existing state's RowData, but leave out the deleted entry.  This will
                //  be faster than rereading the database.
                var testID = this.Id;
                this.prepareNewStateRowList(function(whichRow) {
                    if (whichRow.Id === testID)
                        return null;
                    else
                        return whichRow;


                });




                // var newItemList = [];
                // for (var i = 0; i < this.Parent.state.RowData.length; i++)
                // {
                //     if (this.Parent.state.RowData[i].Id !== this.Id)
                //         newItemList.push(this.Parent.state.RowData[i]);
                // }
                // console.log("Ready to display...");
                // console.log(newItemList);
                // this.Parent.setState({RowData : newItemList});
            });


        }
    }

    /**
     * Make a copy of the row data for the parent's state.  Fire a callback for each one to let the caller change
     * the data or return null if the entries is to be dropped from the list.  When done, give the parent the
     * new list as a state update.
     * @param callback
     */
    prepareNewStateRowList(callback, addNew = false)
    {
        var newItemList = [];
        if (addNew)
            newItemList.push(new RowHolder(this.Parent));
        for (var i = 0; i < this.Parent.state.RowData.length; i++)
        {
            var rowHolder = callback(this.Parent.state.RowData[i]);
            if  (rowHolder !== null)
                newItemList.push(rowHolder);
        }

        this.Parent.setState({RowData : newItemList});


    }
}
// ================================================= ITEM ENTRY =========================================================
class  ItemEntry extends React.Component {

    constructor(props)
    {
        super(props);

        this.state = {
            RowData : [  ],
            DisplayedEntry : -1  //  Row ID of the currently editted entry or -1 if no entry is being editted.
        }


    }

    componentDidMount(){
        //  Send the data to the server as a POST action.
        axios({
            method : 'GET',
            url : "http://localhost:8081/read",

        }).then(res=> {
            // console.log("Reading list from...");
            // console.log(res);
            //  should be returning an array of the items in the table
            var newItemList = [new RowHolder(this)];
            for (var i = 0; i < res.data.length; i++)
            {
                var nextRow = new RowHolder(this);
                nextRow.setFromJSON(res.data[i]);
                newItemList.push(nextRow);
            }
            // console.log("Ready to display...");
            // console.log(newItemList);
            this.setState({RowData : newItemList});
        });



    }

    renderList()
    {
        return (this.state.RowData.map((row) => {
            return row.renderEntry()
        }));
    }

    render() {
        // console.log("Preparing to render...");
        // console.log(this.state.RowData);
        return (
            <div>
                { this.renderList() }
            </div>
        );
    }
}



ReactDOM.render(<ItemEntry />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
